<?php
$hostname="localhost";
$user_name="root";
$password="";
$db="dbfood";
$con=mysqli_connect($hostname,$user_name,$password,$db);

 

?>