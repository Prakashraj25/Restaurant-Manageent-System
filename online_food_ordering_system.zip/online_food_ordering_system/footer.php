<div class="container-fluid animatedParent" style="background:#F8F9FA; padding:40px;"> 
		    <div class="container">
		      
			      <div class="row animated fadeIn">
				     <!--my edition --> 
					  
					  <!-- my edition -->
					  <div class="col-sm-6" style=" border-right:1px solid black;">
					    <ul>
                          <!-- <li><h5>ADMIN SECTION</h5></li> -->
						  <li><img src="img/htb.jpg" width=90 height=90></li>
						  <li><a href="admin.php">Admin Login</a></li>
						  <li><a href="food.php">Add Foods</a></li>
						  
						</ul>
					  </div>
					  
					  <div class="col-sm-6" style=" border-right:1px solid black;">
					     <ul>
						  
						  <li><h5>Healthy food for a healthy body </h5></li>
						  <li><h5>Get the right nutrition for you </h5></li>
						  <li><h5>Unadulterated and fresh</h5> </li>
						  <li><h5>Enjoy health</h5></li>
						  <li><h5>Eat right, live right</h5> </li>
						  
						</ul>
					  </div>
				  </div>
			 </div>
			 			 
		  </div>