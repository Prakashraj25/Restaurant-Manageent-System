-- phpMyAdmin SQL Dump
-- version 2.11.6
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 29, 2021 at 02:24 PM
-- Server version: 5.0.51
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `dbfood`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbadmin`
--

CREATE TABLE `tbadmin` (
  `fld_id` int(10) NOT NULL auto_increment,
  `fld_username` varchar(30) NOT NULL,
  `fld_password` varchar(30) NOT NULL,
  PRIMARY KEY  (`fld_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tbadmin`
--

INSERT INTO `tbadmin` (`fld_id`, `fld_username`, `fld_password`) VALUES
(1, 'admin', 'admin@123');

-- --------------------------------------------------------

--
-- Table structure for table `tbfood`
--

CREATE TABLE `tbfood` (
  `food_id` int(11) NOT NULL auto_increment,
  `fldvendor_id` int(11) NOT NULL,
  `foodname` varchar(100) NOT NULL,
  `cost` bigint(15) NOT NULL,
  `cuisines` varchar(50) NOT NULL,
  `paymentmode` varchar(50) NOT NULL,
  `fldimage` varchar(1000) NOT NULL,
  PRIMARY KEY  (`food_id`),
  KEY `fldvendor_id` (`fldvendor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `tbfood`
--

INSERT INTO `tbfood` (`food_id`, `fldvendor_id`, `foodname`, `cost`, `cuisines`, `paymentmode`, `fldimage`) VALUES
(12, 25, 'Pizza', 65, 'Break fast', 'COD,Online Payment', 'phut_0.jpg'),
(13, 25, 'Pizza Full', 120, 'Break fast', 'COD,Online Payment', 'phut_0.jpg'),
(14, 25, 'bacon', 125, 'Break fast', 'Online Payment', 'bacon breakfast.jpg'),
(15, 25, 'cereal', 150, 'Break fast', 'Online Payment', 'cereal breakfast.png'),
(16, 25, 'sausages', 250, 'Break fast', 'Online Payment', 'sausages breakfast.jpg'),
(17, 25, 'porridge', 135, 'Break fast', 'Online Payment', 'porridge breakfast.jpg'),
(18, 25, 'waffles', 150, 'Break fast', 'Online Payment', 'waffles breakfast.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tblcart`
--

CREATE TABLE `tblcart` (
  `fld_cart_id` int(11) NOT NULL auto_increment,
  `fld_product_id` bigint(11) NOT NULL,
  `fld_customer_id` varchar(50) NOT NULL,
  PRIMARY KEY  (`fld_cart_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `tblcart`
--

INSERT INTO `tblcart` (`fld_cart_id`, `fld_product_id`, `fld_customer_id`) VALUES
(9, 3, 'kumar@gmail.com'),
(11, 9, 'kumar@gmail.com'),
(15, 7, 'varun@gmail.com'),
(24, 14, 'vasanth@gmail.com');

-- --------------------------------------------------------

--
-- Table structure for table `tblcustomer`
--

CREATE TABLE `tblcustomer` (
  `fld_cust_id` int(10) NOT NULL auto_increment,
  `fld_name` varchar(30) NOT NULL,
  `fld_email` varchar(30) NOT NULL,
  `fld_mobile` bigint(10) NOT NULL,
  `password` varchar(30) NOT NULL,
  PRIMARY KEY  (`fld_cust_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `tblcustomer`
--

INSERT INTO `tblcustomer` (`fld_cust_id`, `fld_name`, `fld_email`, `fld_mobile`, `password`) VALUES
(1, 'gajender', 'customer1@gmail.com', 7503515382, 'customer1'),
(2, 'sanjay', 'customer2@gmail.com', 7503515386, 'customer2'),
(3, 'saana', 'customer3@gmail.com', 7503515383, 'customer3'),
(4, 'kumar', 'kumar@gmail.com', 9874563210, '12345'),
(5, 'Arun', 'arun@gmail.com', 9874561252, '12345'),
(6, 'varun', 'varun@gmail.com', 8974561230, '54321'),
(7, 'vasanth', 'vasanth@gmail.com', 9876543210, '54321');

-- --------------------------------------------------------

--
-- Table structure for table `tblmessage`
--

CREATE TABLE `tblmessage` (
  `fld_msg_id` int(10) NOT NULL auto_increment,
  `fld_name` varchar(50) NOT NULL,
  `fld_email` varchar(50) NOT NULL,
  `fld_phone` bigint(10) default NULL,
  `fld_msg` varchar(200) NOT NULL,
  PRIMARY KEY  (`fld_msg_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `tblmessage`
--

INSERT INTO `tblmessage` (`fld_msg_id`, `fld_name`, `fld_email`, `fld_phone`, `fld_msg`) VALUES
(1, 'varun', 'varun@gmail.com', 9876543210, 'good');

-- --------------------------------------------------------

--
-- Table structure for table `tblorder`
--

CREATE TABLE `tblorder` (
  `fld_order_id` int(10) NOT NULL auto_increment,
  `fld_cart_id` bigint(10) NOT NULL,
  `fldvendor_id` bigint(10) default NULL,
  `fld_food_id` bigint(10) default NULL,
  `fld_email_id` varchar(50) default NULL,
  `fld_payment` varchar(20) default NULL,
  `fldstatus` varchar(20) default NULL,
  PRIMARY KEY  (`fld_order_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=17 ;

--
-- Dumping data for table `tblorder`
--

INSERT INTO `tblorder` (`fld_order_id`, `fld_cart_id`, `fldvendor_id`, `fld_food_id`, `fld_email_id`, `fld_payment`, `fldstatus`) VALUES
(1, 1, 21, 1, 'customer3@gmail.com', '50', 'Delivered'),
(2, 2, 22, 3, 'customer3@gmail.com', '20', 'Delivered'),
(3, 3, 22, 3, 'customer1@gmail.com', '20', 'Delivered'),
(4, 4, 24, 9, 'kumar@gmail.com', '10', 'Delivered'),
(5, 5, 23, 5, 'kumar@gmail.com', '100', 'cancelled'),
(6, 6, 23, 5, 'kumar@gmail.com', '100', 'cancelled'),
(7, 7, 22, 2, 'kumar@gmail.com', '50', 'Delivered'),
(8, 8, 24, 9, 'kumar@gmail.com', '10', 'In Process'),
(9, 10, 24, 10, 'arun@gmail.com', '45', 'In Process'),
(10, 12, 22, 2, 'arun@gmail.com', '50', 'Delivered'),
(11, 16, 25, 12, 'varun@gmail.com', '65', 'Delivered'),
(12, 17, 25, 16, 'varun@gmail.com', '250', 'Delivered'),
(13, 18, 25, 18, 'varun@gmail.com', '150', 'Delivered'),
(14, 19, 25, 14, 'varun@gmail.com', '125', 'Delivered'),
(15, 20, 25, 13, 'varun@gmail.com', '120', 'Delivered'),
(16, 22, 25, 16, 'varun@gmail.com', '250', 'cancelled');

-- --------------------------------------------------------

--
-- Table structure for table `tbltable`
--

CREATE TABLE `tbltable` (
  `fld_name` varchar(50) NOT NULL,
  `fld_email` varchar(100) NOT NULL,
  `fld_phone` bigint(20) NOT NULL,
  `fld_date` date NOT NULL,
  `fld_time` varchar(20) NOT NULL,
  `fld_num` int(11) NOT NULL,
  `fld_message` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbltable`
--

INSERT INTO `tbltable` (`fld_name`, `fld_email`, `fld_phone`, `fld_date`, `fld_time`, `fld_num`, `fld_message`) VALUES
('varun', 'varun@gmail.com', 9876543210, '0000-00-00', '2:00 PM', 2, 'good'),
('vasanth', 'vasanth@gmail.com', 9876543210, '0000-00-00', '9:00PM', 4, 'family'),
('muthu', 'muthu@gmail.com', 9874563210, '0000-00-00', '2:00 PM', 6, 'hotel');

-- --------------------------------------------------------

--
-- Table structure for table `tblvendor`
--

CREATE TABLE `tblvendor` (
  `fldvendor_id` int(10) NOT NULL auto_increment,
  `fld_name` varchar(30) NOT NULL,
  `fld_email` varchar(50) NOT NULL,
  `fld_password` varchar(50) NOT NULL,
  `fld_mob` bigint(10) NOT NULL,
  `fld_phone` bigint(10) NOT NULL,
  `fld_address` varchar(50) NOT NULL,
  `fld_logo` varchar(250) NOT NULL,
  PRIMARY KEY  (`fldvendor_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `tblvendor`
--

INSERT INTO `tblvendor` (`fldvendor_id`, `fld_name`, `fld_email`, `fld_password`, `fld_mob`, `fld_phone`, `fld_address`, `fld_logo`) VALUES
(25, 'admin', 'admin@gmail.com', 'admin@123', 9874563210, 112365241, 'Chennai', 'saravanan.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `tbpayment`
--

CREATE TABLE `tbpayment` (
  `fld_cust_id` bigint(20) NOT NULL,
  `fld_name` varchar(50) NOT NULL,
  `fld_email` varchar(50) NOT NULL,
  `fld_address` varchar(200) NOT NULL,
  `fld_city` varchar(100) NOT NULL,
  `fld_state` varchar(50) NOT NULL,
  `fld_zip` varchar(10) NOT NULL,
  `fld_nameoncard` varchar(50) NOT NULL,
  `fld_cardno` bigint(30) NOT NULL,
  `fld_expmonth` varchar(10) NOT NULL,
  `fld_expyear` varchar(10) NOT NULL,
  `fld_cvv` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbpayment`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `tbfood`
--
ALTER TABLE `tbfood`
  ADD CONSTRAINT `tbfood_ibfk_1` FOREIGN KEY (`fldvendor_id`) REFERENCES `tblvendor` (`fldvendor_id`);
